'''
This game is a stratigic turn based version of tic tac toe with a sustainability theme. The game
logic uses an AI agent that is unbeatable, by implementing a minmax alpha-beta pruning tree.
The AI opponent will make decisions and respond to the users move dynamically, pruning inferior moves 
as it goes. This results in an almost unbeatable AI opponent that always takes the most efficent options. 
The game shows a visual of the battle between nature and pollution, with nature being represented
with a tree emoji and pollition being represented by a factory emoji. It is able to display this with
a custom GUI made with Tkinter.
'''

import tkinter as tk
from tkinter import messagebox
import math

# Constants
EMPTY = ""
PLAYER = "🏭"       # Human - Pollution
AI = "🌳"            # AI - Sustainability

# Initialize game state
board = [[EMPTY for _ in range(3)] for _ in range(3)]

# Tkinter GUI setup
game = tk.Tk()
game.title("Sustainability Showdown - Tic Tac Toe")
game.geometry("450x450")

buttons = [[None for _ in range(3)] for _ in range(3)]

# Game logic functions
def check_winner(player):
    for i in range(3):
        if all(board[i][j] == player for j in range(3)) or \
           all(board[j][i] == player for j in range(3)):
            return True
    return all(board[i][i] == player for i in range(3)) or \
           all(board[i][2 - i] == player for i in range(3))

def is_full():
    return all(cell != EMPTY for row in board for cell in row)

def get_available_moves():
    return [(i, j) for i in range(3) for j in range(3) if board[i][j] == EMPTY]

def minimax(depth, is_maximizing, alpha, beta):
    if check_winner(AI):
        return 10 - depth, None
    if check_winner(PLAYER):
        return depth - 10, None
    if is_full():
        return 0, None
    
    best_move = None
    if is_maximizing:
        max_eval = -math.inf
        for move in get_available_moves():
            i, j = move
            board[i][j] = AI
            eval, _ = minimax(depth + 1, False, alpha, beta)
            board[i][j] = EMPTY
            if eval > max_eval:
                max_eval = eval
                best_move = move
            alpha = max(alpha, eval)
            if beta <= alpha:
                break
        return max_eval, best_move
    else:
        min_eval = math.inf
        for move in get_available_moves():
            i, j = move
            board[i][j] = PLAYER
            eval, _ = minimax(depth + 1, True, alpha, beta)
            board[i][j] = EMPTY
            if eval < min_eval:
                min_eval = eval
                best_move = move
            beta = min(beta, eval)
            if beta <= alpha:
                break
        return min_eval, best_move

def ai_move():
    _, move = minimax(0, True, -math.inf, math.inf)
    if move:
        i, j = move
        board[i][j] = AI
        buttons[i][j].config(text=AI, state="disabled")
        
        game.update()
        
        if check_winner(AI):
            game.after(100, lambda: messagebox.showinfo("Game Over", "Sustainability wins! 🌍"))
            game.after(200, reset_game)
        elif is_full():
            game.after(100, lambda: messagebox.showinfo("Game Over", "It's a draw!"))
            game.after(200, reset_game)

def on_click(i, j):
    if board[i][j] == EMPTY:
        board[i][j] = PLAYER
        buttons[i][j].config(text=PLAYER, state="disabled")
        
        # Update the display before checking win conditions
        game.update()
        
        if check_winner(PLAYER):
            game.after(100, lambda: messagebox.showinfo("Game Over", "Pollution wins! 😡"))
            game.after(200, reset_game)
        elif is_full():
            game.after(100, lambda: messagebox.showinfo("Game Over", "It's a draw!"))
            game.after(200, reset_game)
        else:
            game.after(200, ai_move)

def reset_game():
    global board
    board = [[EMPTY for _ in range(3)] for _ in range(3)]
    for i in range(3):
        for j in range(3):
            buttons[i][j].config(text="", state="normal")

# Configure grid to expand with window
for i in range(3):
    game.grid_rowconfigure(i, weight=1)
    game.grid_columnconfigure(i, weight=1)

# Build the GUI grid with larger buttons
for i in range(3):
    for j in range(3):
        button = tk.Button(game, text="", font=('Arial', 36), width=3, height=1,
                          command=lambda i=i, j=j: on_click(i, j))
        button.grid(row=i, column=j, sticky="nsew", padx=5, pady=5)
        buttons[i][j] = button

game.mainloop()