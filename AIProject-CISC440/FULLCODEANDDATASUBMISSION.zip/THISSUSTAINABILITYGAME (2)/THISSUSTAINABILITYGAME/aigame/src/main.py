# src/main.py

from game import TriviaGame

if __name__ == '__main__':
    # point at your questions JSON (adjust path if needed)
    TriviaGame('assets/questions/questions.json').run()
