import json
from openai import Image

def load_prompts(path):
    with open(path) as f:
        return json.load(f)

def load_captions(path):
    with open(path) as f:
        return json.load(f)

# Offline image generation
async def generate_images(prompts, output_dir='assets/images'):
    for p in prompts:
        img = await Image.create(prompt=p['text'], size="512x512", n=1)
        filepath = f"{output_dir}/{p['id']}.png"
        with open(filepath, "wb") as f:
            f.write(img.data[0].image)
