import json
from openai import ChatCompletion

def load_policies(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)

def load_simulations(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)

# Example async function for policy generation (offline use)
async def generate_policy_suggestions():
    client = ChatCompletion()
    resp = await client.create(
        model="gpt-4",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are an expert in environmental policy. "
                    "Generate 5 bold sustainability policy suggestions. "
                    "For each, include a unique id, a short title, a one-sentence description, "
                    "an AI-forecast metric for 2035 (Mt CO2), "
                    "and a current real-world pilot data point."
                )
            }
        ]
    )
    return resp.choices[0].message.content
