import os, random, time, sys, json
import pygame

# ─── Path Resolution ─────────────────────────────────────────────────────────
SCRIPT_DIR       = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT     = os.path.dirname(SCRIPT_DIR)
BG_IMAGE_PATH    = os.path.join(PROJECT_ROOT, 'assets', 'background.png')
SOUND_COR_PATH   = os.path.join(PROJECT_ROOT, 'assets', 'sounds',    'correct.wav')
SOUND_WRONG_PATH = os.path.join(PROJECT_ROOT, 'assets', 'sounds',    'wrong.wav')
MUSIC_AMB_PATH   = os.path.join(PROJECT_ROOT, 'assets', 'music',     'ambience.mp3')
IMG_DIR          = os.path.join(PROJECT_ROOT, 'assets', 'images')

# ─── Constants & Palette ─────────────────────────────────────────────────────
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
BG_COLOR    = (20, 25, 35)
BTN_COLOR   = (48, 138, 156)
BTN_HOVER   = (64, 182, 196)
BTN_PRESS   = (32,  92, 104)
TEXT_COLOR  = (235,235,240)
TIMER_COLOR = (72,209,72)
GREEN       = (72,209,72)
RED         = (220,20,60)

# ─── Init Pygame & Mixer ────────────────────────────────────────────────────
pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()
pygame.mixer.init()

# ─── Fonts & Sounds ──────────────────────────────────────────────────────────
TITLE_FONT   = pygame.font.Font(None, 48)
FONT         = pygame.font.Font(None, 28)
SMALL        = pygame.font.Font(None, 20)
VERDICT_FONT = pygame.font.Font(None, 54)

correct_snd = pygame.mixer.Sound(SOUND_COR_PATH)   if os.path.exists(SOUND_COR_PATH)   else None
wrong_snd   = pygame.mixer.Sound(SOUND_WRONG_PATH) if os.path.exists(SOUND_WRONG_PATH) else None

if os.path.exists(MUSIC_AMB_PATH):
    pygame.mixer.music.load(MUSIC_AMB_PATH)
    pygame.mixer.music.set_volume(0.3)
    pygame.mixer.music.play(-1)

# ─── Utility ─────────────────────────────────────────────────────────────────
def wrap_text(text, font, max_width):
    words, lines, cur = text.split(' '), [], ""
    for w in words:
        test = (cur + " " + w).strip()
        if font.size(test)[0] <= max_width:
            cur = test
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines

def draw_text(surf, txt, pos, font=FONT, color=TEXT_COLOR):
    surf.blit(font.render(txt, True, color), pos)

# ─── Button with Hover & Press ────────────────────────────────────────────────
class Button:
    def __init__(self, rect, text):
        self.rect    = pygame.Rect(rect)
        self.text    = text
        self.pressed = False

    def draw(self, surf, mouse):
        if self.pressed:
            col = BTN_PRESS
        elif self.rect.collidepoint(mouse):
            col = BTN_HOVER
        else:
            col = BTN_COLOR
        pygame.draw.rect(surf, col, self.rect, border_radius=8)
        lbl = FONT.render(self.text, True, TEXT_COLOR)
        surf.blit(lbl, lbl.get_rect(center=self.rect.center))

    def handle(self, event, mouse):
        if event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(mouse):
            self.pressed = True
        elif event.type == pygame.MOUSEBUTTONUP:
            if self.pressed and self.rect.collidepoint(mouse):
                self.pressed = False
                return True
            self.pressed = False
        return False

# ─── Confetti Particle ───────────────────────────────────────────────────────
class Particle:
    def __init__(self, pos):
        self.x, self.y = pos
        self.vx        = random.uniform(-2,2)
        self.vy        = random.uniform(-5,-1)
        self.life      = random.randint(30,60)
        self.color     = random.choice([GREEN, (255,215,0), (135,206,250)])
        self.size      = random.randint(4,7)

    def update(self):
        self.vy += 0.2
        self.x  += self.vx
        self.y  += self.vy
        self.life -= 1

    def draw(self, surf):
        if self.life > 0:
            pygame.draw.circle(surf, self.color, (int(self.x),int(self.y)), self.size)

# ─── JSON Loader ─────────────────────────────────────────────────────────────
def load_json(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)

# ─── Main Game Class ─────────────────────────────────────────────────────────
class TriviaGame:
    def __init__(self, qfile):
        # Initialize display first, so .convert() works
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("THE BEST SUSTAINABILITY GAME EVER")

        # Background
        self.bg = pygame.image.load(BG_IMAGE_PATH).convert() if os.path.exists(BG_IMAGE_PATH) else None

        # Data
        self.questions   = load_json(qfile)
        self.policies    = load_json(os.path.join(PROJECT_ROOT,'assets','policies','policies.json'))
        self.simulations = load_json(os.path.join(PROJECT_ROOT,'assets','simulations','simulations.json'))
        self.images      = [
            os.path.join(IMG_DIR, f)
            for f in os.listdir(IMG_DIR)
            if f.lower().endswith(('.png','jpg','jpeg'))
        ]
        self.current_image = None

        # State
        self.clock        = pygame.time.Clock()
        self.state        = 'MENU'
        self.score        = 0
        self.qlist        = []
        self.total_q      = 0
        self.current_q    = None
        self.q_index      = 0
        self.timer_start  = 0
        self.time_limit   = 30
        self.last_corr    = False
        self.feedback     = ""
        self.current_policy = None
        self.particles    = []

        # Buttons
        self.menu_btns = [
            Button((300,200,200,50),"Play Trivia"),
            Button((300,270,200,50),"AI Research"),
            Button((300,340,200,50),"Gallery"),
            Button((300,410,200,50),"Quit")
        ]
        self.answer_btns = []
        self.next_btn    = Button((350,520,100,40),"Next")
        self.back_btn    = Button((650,520,120,40),"Back")
        self.newimg_btn  = Button((325,520,150,40),"New Image")
        self.newpol_btn  = Button((325,520,150,40),"New Policy")

    def run(self):
        while True:
            mouse = pygame.mouse.get_pos()
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                self.handle_event(e, mouse)

            # update confetti
            for p in self.particles:
                p.update()
            self.particles = [p for p in self.particles if p.life>0]

            self.draw(mouse)
            pygame.display.flip()
            self.clock.tick(60)

    def handle_event(self, e, mouse):
        if self.state == 'MENU':
            for i, btn in enumerate(self.menu_btns):
                if btn.handle(e, mouse):
                    if i == 0:
                        self.start_trivia()
                    elif i == 1:
                        self.start_research()
                    elif i == 2:
                        self.state = 'GALLERY'
                        self.current_image = None
                    else:
                        pygame.quit(); sys.exit()

        elif self.state == 'ASK':
            for idx, btn in enumerate(self.answer_btns):
                if btn.handle(e, mouse):
                    self.process_answer(idx)
            if self.back_btn.handle(e, mouse):
                self.state = 'MENU'

        elif self.state == 'FEEDBACK':
            if self.next_btn.handle(e, mouse):
                self.next_question()
            if self.back_btn.handle(e, mouse):
                self.state = 'MENU'

        elif self.state == 'RESEARCH':
            if self.newpol_btn.handle(e, mouse):
                self.start_research()
            if self.back_btn.handle(e, mouse):
                self.state = 'MENU'

        elif self.state == 'GALLERY':
            if self.newimg_btn.handle(e, mouse):
                self.generate_image()
            if self.back_btn.handle(e, mouse):
                self.state = 'MENU'

    def draw(self, mouse):
        # background
        if self.bg:
            self.screen.blit(self.bg, (0,0))
        else:
            self.screen.fill(BG_COLOR)

        # MENU
        if self.state == 'MENU':
            draw_text(self.screen, "Sustainability Game", (220,140), TITLE_FONT)
            for btn in self.menu_btns:
                btn.draw(self.screen, mouse)

        # ASK
        elif self.state == 'ASK':
            draw_text(self.screen, f"Question {self.q_index}/{self.total_q}", (50,20), SMALL)
            elapsed = time.time() - self.timer_start
            pct     = max(0, (self.time_limit - elapsed) / self.time_limit)
            pygame.draw.rect(self.screen, TIMER_COLOR, (50,50,700*pct,20))
            for i, line in enumerate(wrap_text(self.current_q['question'], FONT, 700)):
                draw_text(self.screen, line, (50,100 + i*30))
            for btn in self.answer_btns:
                btn.draw(self.screen, mouse)
            self.back_btn.draw(self.screen, mouse)
            draw_text(self.screen, f"Score: {self.score}", (650,20), SMALL)
            if elapsed >= self.time_limit:
                self.process_timeout()

        # FEEDBACK
        elif self.state == 'FEEDBACK':
            draw_text(self.screen, f"Question {self.q_index}/{self.total_q} — Score: {self.score}", (50,20), SMALL)
            txt = "Correct!" if self.last_corr else "Wrong!"
            col = GREEN if self.last_corr else RED
            self.screen.blit(VERDICT_FONT.render(txt, True, col), (300,260))
            for p in self.particles:
                p.draw(self.screen)
            for i, line in enumerate(wrap_text(self.feedback, FONT, 700)):
                draw_text(self.screen, line, (50,320 + i*30))
            self.next_btn.draw(self.screen, mouse)
            self.back_btn.draw(self.screen, mouse)

        # RESEARCH
        elif self.state == 'RESEARCH':
            draw_text(self.screen, f"Policy: {self.current_policy['title']}", (50,100))
            draw_text(self.screen, f"Forecast: {self.current_policy['ai_forecast']}", (50,140), SMALL)
            draw_text(self.screen, f"Real data:   {self.current_policy['real_world']}", (50,180), SMALL)
            self.newpol_btn.draw(self.screen, mouse)
            self.back_btn.draw(self.screen, mouse)

        # GALLERY
        elif self.state == 'GALLERY':
            if self.current_image:
                x = (SCREEN_WIDTH - self.current_image.get_width()) // 2
                y = 50
                self.screen.blit(self.current_image, (x,y))
            else:
                draw_text(self.screen, "Click 'New Image' to load a random image", (180,280), TITLE_FONT)
            self.newimg_btn.draw(self.screen, mouse)
            self.back_btn.draw(self.screen, mouse)

    # ─── Trivia ────────────────────────────────────────────────────────────────
    def start_trivia(self):
        self.state  = 'ASK'
        self.score  = 0
        self.qlist  = random.sample(self.questions, 10)
        self.total_q= len(self.qlist)
        self.q_index= 0
        self.next_question()

    def next_question(self):
        if not self.qlist:
            self.state = 'MENU'
            return
        self.current_q   = self.qlist.pop(0)
        self.q_index    += 1
        self.timer_start = time.time()
        self.answer_btns = [
            Button((100,180 + i*60, 600, 40), f"{i+1}) {c}")
            for i, c in enumerate(self.current_q['choices'])
        ]
        self.state = 'ASK'

    def process_answer(self, idx):
        chosen     = self.current_q['choices'][idx]
        self.last_corr = (chosen == self.current_q['correct'])
        if self.last_corr:
            self.score   += 10
            self.feedback = self.current_q['explanation']
            if correct_snd:
                correct_snd.play()
            for _ in range(20):
                self.particles.append(Particle((400,300)))
        else:
            self.feedback = (
                f"Answer was {self.current_q['correct']}. {self.current_q['explanation']}"
            )
            if wrong_snd:
                wrong_snd.play()
        self.state = 'FEEDBACK'

    def process_timeout(self):
        self.last_corr = False
        self.feedback  = f"Time's up! Answer was {self.current_q['correct']}."
        if wrong_snd:
            wrong_snd.play()
        self.state = 'FEEDBACK'

    # ─── Research ───────────────────────────────────────────────────────────────
    def start_research(self):
        self.current_policy = random.choice(self.policies)
        self.state          = 'RESEARCH'

    # ─── Gallery ────────────────────────────────────────────────────────────────
    def generate_image(self):
        if not self.images:
            return
        path = random.choice(self.images)
        img  = pygame.image.load(path).convert_alpha()
        w,h  = img.get_size()
        scale= min(700/w, 400/h, 1)
        self.current_image = pygame.transform.smoothscale(img, (int(w*scale), int(h*scale)))

# ─── Entry Point ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    TriviaGame(os.path.join(PROJECT_ROOT,'assets','questions','questions.json')).run()
