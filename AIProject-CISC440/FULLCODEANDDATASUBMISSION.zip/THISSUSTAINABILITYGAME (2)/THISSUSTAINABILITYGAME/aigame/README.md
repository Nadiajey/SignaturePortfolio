# Sustainability Trivia & Research Game

**Setup:**
```bash
# After unzipping and navigating into the project folder:
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

**Run:**
```bash
python src/main.py
```
