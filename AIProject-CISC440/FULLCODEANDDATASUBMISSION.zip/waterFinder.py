import tkinter as tk
from tkinter import messagebox
import random

CELL_SIZE = 80 
GRID_SIZE = 5
WELL_RANGE = 2

def generate_grid():
    return [["H" if random.random() < 0.3 else "." for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]

grid = generate_grid()
placed_wells = set()
uncovered_houses = [] 

def is_house_covered(house, wells):
    for wx, wy in wells:
        if abs(house[0] - wx) + abs(house[1] - wy) <= WELL_RANGE:
            return True
    return False

def check_solution():
    global uncovered_houses
    houses = [(r, c) for r in range(GRID_SIZE) for c in range(GRID_SIZE) if grid[r][c] == "H"]
    uncovered_houses = [h for h in houses if not is_house_covered(h, placed_wells)]

    draw_grid()  

    if uncovered_houses:
        messagebox.showerror("Try Again", f"{len(uncovered_houses)} house(s) are not covered.")
    else:
        messagebox.showinfo("Success", "All houses are covered! You win!")

def draw_grid():
    canvas.delete("all")
    for r in range(GRID_SIZE):
        for c in range(GRID_SIZE):
            x0, y0 = c * CELL_SIZE, r * CELL_SIZE
            x1, y1 = x0 + CELL_SIZE, y0 + CELL_SIZE

            fill = "white"
            label = grid[r][c]

            if grid[r][c] == "H":
                if (r, c) in uncovered_houses: 
                    fill = "salmon"
                else:
                    fill = "lightblue"
            elif (r, c) in placed_wells:
                fill = "green"
                label = "W"

            canvas.create_rectangle(x0, y0, x1, y1, fill=fill, outline="black")
            canvas.create_text((x0 + x1) // 2, (y0 + y1) // 2, text=label, font=("Arial", 20))

def handle_click(event):
    col = event.x // CELL_SIZE
    row = event.y // CELL_SIZE

    if 0 <= row < GRID_SIZE and 0 <= col < GRID_SIZE:
        if grid[row][col] == ".":
            if (row, col) in placed_wells:
                placed_wells.remove((row, col))
            else:
                placed_wells.add((row, col))
            draw_grid()

def reset_game():
    global grid, placed_wells, uncovered_houses
    grid = generate_grid()
    placed_wells = set()
    uncovered_houses = []  
    draw_grid()

def auto_solve_greedy():
    global placed_wells, uncovered_houses
    placed_wells = set()
    
    houses = [(r, c) for r in range(GRID_SIZE) for c in range(GRID_SIZE) if grid[r][c] == "H"]
    uncovered = set(houses)

    while uncovered:
        best_spot = None
        max_covered = 0

        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                if grid[r][c] == "." and (r, c) not in placed_wells:
                    covered_now = [
                        h for h in uncovered if abs(h[0] - r) + abs(h[1] - c) <= WELL_RANGE
                    ]
                    if len(covered_now) > max_covered:
                        max_covered = len(covered_now)
                        best_spot = (r, c)

        if not best_spot:
            break

        placed_wells.add(best_spot)
        uncovered -= {h for h in uncovered if abs(h[0] - best_spot[0]) + abs(h[1] - best_spot[1]) <= WELL_RANGE}

    uncovered_houses = list(uncovered)
    draw_grid()

    if uncovered_houses:
        messagebox.showinfo("Auto Solve Result", f"Couldn't cover {len(uncovered_houses)} house(s).")
    else:
        messagebox.showinfo("Auto Solve Result", "All houses covered using greedy strategy!")

# GUI setup
root = tk.Tk()
root.title("Neighborhood Water Planner - CSP Game")

canvas = tk.Canvas(root, width=GRID_SIZE * CELL_SIZE, height=GRID_SIZE * CELL_SIZE)
canvas.pack()
canvas.bind("<Button-1>", handle_click)

frame = tk.Frame(root)
frame.pack(pady=10)

check_btn = tk.Button(frame, text="Check Solution", command=check_solution)
check_btn.pack(side=tk.LEFT, padx=10)

reset_btn = tk.Button(frame, text="Reset Grid", command=reset_game)
reset_btn.pack(side=tk.LEFT, padx=10)

solve_btn = tk.Button(frame, text="Auto Solve", command=auto_solve_greedy)
solve_btn.pack(side=tk.LEFT, padx=10)

draw_grid()
root.mainloop()
