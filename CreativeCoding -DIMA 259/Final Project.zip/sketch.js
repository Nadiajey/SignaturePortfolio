// Click to start/stop animation
// Click keyboard to change background
let song;
let fft;
let landscape;
let slider;
let colorPicker;
let colorPicker2;
let colorPicker3;
let particles = [];

function preload() {
  // Uncomment one of the following lines to load your sound file
  // song = loadSound("Can Let Go.mp3");
  song = loadSound(' Can Let Go.mp3');
  // landscape = loadImage('landscape.jpeg');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  angleMode(DEGREES);
  slider = createSlider(1, 8, 3, 0);
  slider.position(100);
  colorPicker = createColorPicker("#ADD8E6");
  colorPicker.position(50);
  colorPicker2 = createColorPicker("#001455");
  this.color2 = [random(0, 255), random(0, 255), random(255, 255)];
  colorPicker2.position(0);
  fft = new p5.FFT();
}

function draw() {
  // imageMode(CENTER);
  background(0, 0, 0, 5);
  stroke(255);
  strokeWeight(3);
  noFill();
  //image(landscape, width/2, height/2);
  stroke(colorPicker2.color());
  fill(colorPicker.color());

  translate(width / 2, height / 2);

  fft.analyze();
  let amp = fft.getEnergy(20, 200);
  let wave = fft.waveform();
  for (let t = -1; t <= 1; t += 2) {
    beginShape();
    for (let i = 0; i <= 180; i += 2.5) {
      let index = floor(map(i, 0, 180, 0, wave.length - 1));
      let r = map(wave[index], -1, 1, -50, 50);
      let x = r * sin(i) * t;
      let y = r * cos(i);
      vertex(x, y);
    }
    endShape();
  }

  if (amp > 230) {
    rotate(random(-0.5, 0.5)); // Add some random rotation when amplitude is high
  }

  for (let i = 0; i < 10; i++) { // Create more particles
    let p = new Particle();
    particles.push(p);
  }

  for (let i = 0; i < particles.length; i++) {
    if (!particles[i].edges()) {
      particles[i].update(amp > 230);
      particles[i].show();
    } else {
      particles.splice(i, 1);
    }
  }

  if (keyIsPressed === true) {
    background(255, 255, 255, 5);
  } else {
    background(0, 0, 0, 5);
  }
}

function mousePressed() {
  if (song.isPlaying()) {
    song.pause();
    noLoop();
  } else {
    song.play();
    loop();
  }
}

class Particle {
  constructor() {
    this.pos = p5.Vector.random2D().mult(20);
    this.vel = createVector(0, 0);
    this.acc = this.pos.copy().mult(random(0.0001, 0.00001));

    this.w = random(3, 5);
    let pink = color(255, 192, 203); // Pink color
    let mainColor = colorPicker.color(); // Color from colorPicker
    this.color = lerpColor(pink, mainColor, 0.5); // Blend pink and mainColor
  }
  update(cond) {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    if (cond) {
      this.pos.add(this.vel);
      this.pos.add(this.vel);
      this.pos.add(this.vel);
      this.pos.add(this.vel);
    }
  }
  edges() {
    if (
      this.pos.x < -width / 2 ||
      this.pos.x > width / 2 ||
      this.pos.y < -height / 2 ||
      this.pos.y > height / 2
    ) {
      return true;
    } else {
      return false;
    }
  }
  show() {
    noStroke();
    fill(this.color); // Use the blended color
    ellipse(this.pos.x, this.pos.y, slider.value());
  }
}
